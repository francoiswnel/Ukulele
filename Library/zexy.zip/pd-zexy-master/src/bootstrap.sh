#!/bin/sh
cd .. && ./autogen.sh
echo "now run './configure'
for help on args run './configure --help'"
