unit tests for testing the unit-tester
some of these tests MUST fail in order to work correctly (to prove that the unit-tester can handle failed tests)
