here you (will) find example patches on how to make use of zexy objects.
the reference-patches (aka help-patches) have been moved to ../reference

mfg.asdr
IOhannes - zmoelnig at iem dot at
