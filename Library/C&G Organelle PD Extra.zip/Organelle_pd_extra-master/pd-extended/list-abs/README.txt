list-abs
--------

A collection of list-processing abstractions for Pd. 

For a list of included objects open list-abs-intro.pd or list-abs-intro.txt

Maintainer: Frank Barknecht <fbar a footils.org>

-- 
