
------------------------------
  GEM and MARKEX
------------------------------

These are objects from GEM which don't have any dependencies besides libc.
What is here is the entire contents of Gem/src/MarkEx except [hsv2rsb] and
the vector lib.  Hopefully they will be removed from Gem once they become a
proper part of this repository.

