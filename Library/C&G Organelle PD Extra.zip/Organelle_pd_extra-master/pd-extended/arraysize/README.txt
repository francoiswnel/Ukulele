   This code is too trivial to have a licence or copyright.

   However it was modeled after arraysize from pixlib,
   http://pix.test.at/pd/pixlib



	arraysize -- report the size of an array
	
	usage: |arraysize <array name>|

	methods: bang, set <array name>

