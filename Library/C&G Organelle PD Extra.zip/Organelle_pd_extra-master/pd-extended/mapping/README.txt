
This is the beginnings of the "mapping" library, which is a combination of
efforts of Cyrille Henry and Hans-Christoph Steiner.  It draws from the hid_*
classes, ds_/datastream classes, and the La-Kitchen classes for working with
sensors.

These classes are for creatively mapping data to something that you want to
control.

